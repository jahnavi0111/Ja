# 🚀 INSTALLATION GUIDE - Advanced Portfolio

## Quick Setup (3 Steps)

```bash
# Step 1: Install dependencies
npm install

# Step 2: Start development server  
npm run dev

# Step 3: Open browser
# Automatically opens at http://localhost:3000
```

## ⚡ What You'll See

When you run `npm run dev`, you'll experience:

1. **Loading Screen** (2 seconds)
   - Animated spinning rings
   - "Loading Experience..." text
   - Smooth fade in

2. **Hero Section** 
   - 3D rotating sphere with distortion
   - Particle field (2000+ particles)
   - Glowing ring
   - Interactive orbit controls
   - Glitch text effect
   - Animated statistics

3. **Particle Background**
   - 100+ interactive particles throughout site
   - Mouse hover creates connections
   - Click to spawn new particles

4. **Custom Cursor**
   - Cyan glowing dot
   - Expanding outline on hover
   - Smooth following animation

5. **Smooth Scroll Through**:
   - About section with floating circles
   - 3D Skills with interactive orbs
   - Filtered project showcase
   - Timeline experience
   - Contact form with animations

## 🎮 Interactive Features

### Mouse Interactions
- **Hover over particles** - See connections form
- **Click anywhere** - Spawn 4 new particles
- **Hover buttons/links** - Cursor expands
- **Drag 3D elements** - Orbit controls active

### Animations Triggered by:
- **Scrolling** - Components fade and slide in
- **Hovering cards** - Lift and glow effects
- **Clicking projects** - Full-screen modal opens
- **Form submission** - Success animation plays

## 📱 Responsive Testing

```bash
# Desktop (Full experience)
- All 3D effects active
- Custom cursor enabled
- Particle count: 2000+

# Tablet (Optimized)
- Reduced particles
- Touch-friendly
- Simplified 3D

# Mobile (Mobile-first)
- Custom cursor disabled
- Optimized particles
- Touch gestures enabled
```

## 🎨 Customization After Install

### Change Colors (Easy)
Open `src/styles/index.css`:
```css
:root {
  --primary-color: #your-color;
  --secondary-color: #your-color;
  --accent-color: #your-color;
}
```

### Modify 3D Effects (Medium)
Open `src/components/Hero3D.jsx`:
```javascript
// Line 25: Change sphere distortion
distort={0.5}  // 0-1 range

// Line 41: Change particle count
const count = 2000; // Reduce for performance

// Line 25: Change animation speed
speed={2} // Higher = faster
```

### Add Your Projects (Easy)
Open `src/components/Projects.jsx`:
```javascript
// Line 10: Add your projects to array
const projects = [
  {
    title: 'Your Project',
    category: 'web', // or '3d', 'ai'
    description: 'Your description',
    image: 'your-image-url',
    technologies: ['Tech1', 'Tech2'],
    link: '#your-link'
  },
  // ... more projects
];
```

### Update Your Info (Easy)
- **Name/Title**: `src/components/Hero3D.jsx` line 88-95
- **About Text**: `src/components/About.jsx` line 12-20
- **Skills**: `src/components/Skills3D.jsx` line 48-78
- **Experience**: `src/components/Experience.jsx` line 8-29
- **Contact**: `src/components/Contact.jsx` line 44-65

## 🔧 Build for Production

```bash
# Create optimized build
npm run build

# Preview production build
npm run preview

# Deploy 'dist' folder to:
# - Vercel
# - Netlify
# - GitHub Pages
# - Any static host
```

## 🐛 Common Issues & Fixes

### Issue: Blank screen
**Fix**: Check browser console, ensure Node v14.21.3
```bash
node --version  # Should show v14.21.3
```

### Issue: 3D not loading
**Fix**: Clear cache and reinstall
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: Particles not showing
**Fix**: Check particles.js is loaded in index.html
```html
<script src="https://cdn.jsdelivr.net/npm/particles.js@2.0.0/particles.min.js"></script>
```

### Issue: Port 3000 in use
**Fix**: Edit `vite.config.js`
```javascript
server: {
  port: 3001, // Change port number
}
```

### Issue: Slow performance
**Fix**: Reduce particle count in Hero3D.jsx
```javascript
const count = 500; // Instead of 2000
```

## 📊 Performance Tips

### For Development
- Use Chrome DevTools Performance tab
- Monitor FPS (should be 60fps)
- Check bundle size with `npm run build`

### For Production
- Images should be optimized (WebP format)
- Enable gzip compression on server
- Use CDN for static assets
- Lazy load images

### Optimization Checklist
- [ ] Optimize all images
- [ ] Remove unused dependencies
- [ ] Enable production mode
- [ ] Test on mobile devices
- [ ] Check Lighthouse score

## 🎓 Learn More

**Three.js Documentation**
- https://threejs.org/docs/

**React Three Fiber**
- https://docs.pmnd.rs/react-three-fiber

**Framer Motion**
- https://www.framer.com/motion/

**Vite**
- https://vitejs.dev/

## 🚀 Next Steps

After installation:

1. **Customize Content**
   - Update personal information
   - Add your projects
   - Change colors to match brand

2. **Test Everything**
   - Click all buttons
   - Test on mobile
   - Check all animations

3. **Deploy**
   - Build for production
   - Choose hosting platform
   - Deploy and share!

## 💡 Tips for Best Results

- **Keep Node v14.21.3** - Don't upgrade mid-project
- **Test on real devices** - Not just browser DevTools
- **Optimize images** - Use TinyPNG or similar
- **Monitor performance** - Use Lighthouse regularly
- **Git version control** - Commit changes frequently

---

**Need help?** Check README.md and FEATURES.md for more details!

Enjoy your stunning portfolio! 🎨✨
