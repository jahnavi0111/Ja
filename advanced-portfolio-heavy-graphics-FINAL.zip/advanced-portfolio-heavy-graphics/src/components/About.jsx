import React from 'react';
import { motion } from 'framer-motion';
import '../styles/About.css';

const About = () => {
  return (
    <section className="about" id="about">
      <div className="about-container">
        <motion.div
          initial={{ opacity: 0, x: -100 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="about-content"
        >
          <h2 className="gradient-text">About Me</h2>
          <p className="about-text">
            I'm a creative developer specializing in crafting immersive digital experiences
            that push the boundaries of web technology. With expertise in 3D graphics, WebGL,
            and modern frontend frameworks, I transform complex ideas into stunning visual realities.
          </p>
          <p className="about-text">
            My passion lies in the intersection of art and code, where I leverage cutting-edge
            technologies like Three.js, GSAP, and React to create experiences that captivate
            and engage users.
          </p>
          
          <div className="about-highlights">
            <div className="highlight-item">
              <div className="highlight-icon">🎨</div>
              <h3>Creative Vision</h3>
              <p>Transforming ideas into visual masterpieces</p>
            </div>
            <div className="highlight-item">
              <div className="highlight-icon">⚡</div>
              <h3>Performance</h3>
              <p>Optimized for speed and efficiency</p>
            </div>
            <div className="highlight-item">
              <div className="highlight-icon">🚀</div>
              <h3>Innovation</h3>
              <p>Using latest web technologies</p>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 100 }}
          whileInView={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="about-visual"
        >
          <div className="visual-wrapper">
            <div className="visual-circle circle-1"></div>
            <div className="visual-circle circle-2"></div>
            <div className="visual-circle circle-3"></div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
