import React, { useRef } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Float, Text, OrbitControls } from '@react-three/drei';
import { motion } from 'framer-motion';
import '../styles/Skills3D.css';

// 3D Skill Orb
function SkillOrb({ position, color, skill, index }) {
  const meshRef = useRef();

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    meshRef.current.position.y = position[1] + Math.sin(time + index) * 0.3;
    meshRef.current.rotation.y = time * 0.5;
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={0.5}>
      <mesh ref={meshRef} position={position}>
        <icosahedronGeometry args={[0.5, 1]} />
        <meshStandardMaterial
          color={color}
          emissive={color}
          emissiveIntensity={0.5}
          metalness={0.8}
          roughness={0.2}
        />
        <Text
          position={[0, -0.8, 0]}
          fontSize={0.15}
          color="white"
          anchorX="center"
          anchorY="middle"
        >
          {skill}
        </Text>
      </mesh>
    </Float>
  );
}

// Skill Grid
function SkillGrid() {
  const skills = [
    { name: 'React', color: '#61DAFB', position: [-2, 0, 0] },
    { name: 'Three.js', color: '#000000', position: [0, 0, 0] },
    { name: 'Node.js', color: '#68A063', position: [2, 0, 0] },
    { name: 'TypeScript', color: '#3178C6', position: [-2, -1.5, 0] },
    { name: 'WebGL', color: '#FF0000', position: [0, -1.5, 0] },
    { name: 'GSAP', color: '#88CE02', position: [2, -1.5, 0] },
    { name: 'Blender', color: '#E87D0D', position: [-2, -3, 0] },
    { name: 'Unity', color: '#000000', position: [0, -3, 0] },
    { name: 'Docker', color: '#2496ED', position: [2, -3, 0] },
  ];

  return (
    <>
      {skills.map((skill, index) => (
        <SkillOrb
          key={index}
          position={skill.position}
          color={skill.color}
          skill={skill.name}
          index={index}
        />
      ))}
    </>
  );
}

const Skills3D = () => {
  const skillCategories = [
    {
      title: 'Frontend Development',
      skills: [
        { name: 'React.js', level: 95 },
        { name: 'Three.js / WebGL', level: 90 },
        { name: 'Next.js', level: 88 },
        { name: 'TypeScript', level: 92 },
        { name: 'CSS3 / SASS', level: 95 },
      ]
    },
    {
      title: 'Backend Development',
      skills: [
        { name: 'Node.js', level: 90 },
        { name: 'Python', level: 85 },
        { name: 'GraphQL', level: 82 },
        { name: 'MongoDB', level: 88 },
        { name: 'PostgreSQL', level: 85 },
      ]
    },
    {
      title: '3D & Animation',
      skills: [
        { name: 'Blender', level: 88 },
        { name: 'After Effects', level: 85 },
        { name: 'GSAP', level: 92 },
        { name: 'Framer Motion', level: 90 },
        { name: 'Cinema 4D', level: 80 },
      ]
    }
  ];

  return (
    <section className="skills-3d" id="skills">
      <div className="skills-container">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="section-header"
        >
          <h2 className="gradient-text">Technical Arsenal</h2>
          <p>Mastering the tools that bring visions to life</p>
        </motion.div>

        <div className="skills-3d-canvas">
          <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
            <ambientLight intensity={0.5} />
            <pointLight position={[10, 10, 10]} intensity={1} />
            <pointLight position={[-10, -10, -10]} intensity={0.5} color="#ff00ff" />
            <SkillGrid />
            <OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.5} />
          </Canvas>
        </div>

        <div className="skills-grid">
          {skillCategories.map((category, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: idx % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: idx * 0.2 }}
              viewport={{ once: true }}
              className="skill-category"
            >
              <h3 className="category-title">{category.title}</h3>
              <div className="skills-list">
                {category.skills.map((skill, skillIdx) => (
                  <motion.div
                    key={skillIdx}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.5, delay: skillIdx * 0.1 }}
                    viewport={{ once: true }}
                    className="skill-item"
                  >
                    <div className="skill-info">
                      <span className="skill-name">{skill.name}</span>
                      <span className="skill-percentage">{skill.level}%</span>
                    </div>
                    <div className="skill-bar">
                      <motion.div
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.level}%` }}
                        transition={{ duration: 1, delay: skillIdx * 0.1 }}
                        viewport={{ once: true }}
                        className="skill-progress"
                        style={{
                          background: `linear-gradient(90deg, #00d4ff, #ff00ff)`
                        }}
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills3D;
