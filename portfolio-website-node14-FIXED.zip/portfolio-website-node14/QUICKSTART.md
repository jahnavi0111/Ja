# Quick Start Guide - Node v14.21.3

## Installation (3 steps)

```bash
# 1. Verify Node version
node --version
# Must show: v14.21.3

# 2. Install dependencies
npm install

# 3. Start development server
npm run dev
```

✅ Your portfolio will open automatically at http://localhost:3000

## Commands

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server |
| `npm run build` | Build for production |
| `npm run preview` | Preview production build |

## Need Node v14.21.3?

```bash
# Using nvm (recommended)
nvm install 14.21.3
nvm use 14.21.3

# Or set as default
nvm alias default 14.21.3
```

## What's Included

- ✅ React 18.2.0
- ✅ Vite 4.5.3 (Node 14 compatible)
- ✅ Fully responsive design
- ✅ Smooth animations
- ✅ Contact form
- ✅ Portfolio showcase

## Troubleshooting

**Dependencies won't install?**
```bash
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

**Port already in use?**
- Vite will automatically use next available port
- Or edit `vite.config.js` to change the port

For detailed instructions, see `SETUP_INSTRUCTIONS.md`
