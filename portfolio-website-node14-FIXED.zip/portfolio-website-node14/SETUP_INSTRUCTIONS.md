# Portfolio Website - Setup Instructions for Node.js v14.21.3

## Prerequisites

- **Node.js v14.21.3** (required)
- **npm** (comes with Node.js)

## Verify Node Version

Before starting, verify you have the correct Node.js version:

```bash
node --version
# Should output: v14.21.3
```

If you need to install Node.js v14.21.3, you can use [nvm (Node Version Manager)](https://github.com/nvm-sh/nvm):

```bash
# Install nvm (if not already installed)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash

# Install and use Node v14.21.3
nvm install 14.21.3
nvm use 14.21.3
```

## Installation Steps

1. **Extract the project** (if you haven't already)
   ```bash
   unzip portfolio-website.zip
   cd portfolio-website
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```
   
   This will install:
   - React 18.2.0
   - React DOM 18.2.0
   - Vite 4.5.3 (compatible with Node 14)
   - @vitejs/plugin-react 4.0.0

3. **Start the development server**
   ```bash
   npm run dev
   ```
   
   The application will automatically open in your browser at `http://localhost:3000`

## Available Scripts

- **`npm run dev`** - Start development server (opens browser automatically)
- **`npm run build`** - Build for production (creates `dist` folder)
- **`npm run preview`** - Preview production build locally

## Project Structure

```
portfolio-website/
├── src/
│   ├── components/      # React components
│   │   ├── Navbar.jsx
│   │   ├── Hero.jsx
│   │   ├── About.jsx
│   │   ├── Services.jsx
│   │   ├── Portfolio.jsx
│   │   ├── Testimonials.jsx
│   │   ├── Contact.jsx
│   │   └── Footer.jsx
│   ├── data/           # Data files
│   │   ├── servicesData.js
│   │   ├── portfolioData.js
│   │   └── testimonialsData.js
│   ├── styles/         # CSS files
│   ├── App.jsx         # Main App component
│   └── main.jsx        # Entry point
├── index.html          # HTML template
├── package.json        # Dependencies (Node 14 compatible)
└── vite.config.js      # Vite configuration
```

## What Was Changed for Node v14.21.3 Compatibility

The following updates were made to ensure compatibility with Node.js v14.21.3:

1. **Vite downgraded**: v5.0.0 → v4.5.3
   - Vite 5.x requires Node.js 18+
   - Vite 4.5.3 fully supports Node.js 14.18+

2. **@vitejs/plugin-react adjusted**: v4.2.1 → v4.0.0
   - Ensures compatibility with Vite 4.x

3. **Added engine specification** in package.json:
   ```json
   "engines": {
     "node": ">=14.18.0"
   }
   ```

## Troubleshooting

### Issue: "Error: Cannot find module"
**Solution**: Delete `node_modules` and `package-lock.json`, then reinstall:
```bash
rm -rf node_modules package-lock.json
npm install
```

### Issue: Port 3000 is already in use
**Solution**: The development server will automatically try another port, or you can modify `vite.config.js`:
```javascript
server: {
  port: 3001, // Change to any available port
  open: true
}
```

### Issue: "ERR_OSSL_EVP_UNSUPPORTED" on Node 14
**Solution**: This typically doesn't occur with Vite 4.x, but if you encounter it:
```bash
export NODE_OPTIONS=--openssl-legacy-provider
npm run dev
```

### Issue: Build fails or warnings about dependencies
**Solution**: Clear npm cache and reinstall:
```bash
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

## Building for Production

To create a production-ready build:

```bash
npm run build
```

The optimized files will be in the `dist` folder. You can preview the production build locally:

```bash
npm run preview
```

To deploy, upload the contents of the `dist` folder to your web hosting service (Netlify, Vercel, GitHub Pages, etc.).

## Browser Support

This application supports all modern browsers:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Features

- ✅ Fully responsive design
- ✅ Smooth scroll animations
- ✅ Interactive contact form (frontend only)
- ✅ Portfolio showcase with filtering
- ✅ Services section
- ✅ Testimonials carousel
- ✅ Modern UI with smooth transitions

## Notes

- This is a **frontend-only** application (no backend required)
- The contact form simulates submission (logs to console)
- All animations use CSS and Intersection Observer API
- Images and content can be customized in the data files

## Support

If you encounter any issues:

1. Make sure you're using Node.js v14.21.3
2. Clear node_modules and reinstall dependencies
3. Check that all ports are available
4. Ensure you have sufficient disk space

For additional help, check:
- [Vite Documentation](https://vitejs.dev/)
- [React Documentation](https://react.dev/)
- [Node.js Documentation](https://nodejs.org/)
