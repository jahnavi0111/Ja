# Changelog - Node v14.21.3 Compatibility Update

## Changes Made (February 10, 2026)

### Package Dependencies Updated

#### 1. Vite (Build Tool)
- **Before**: `^5.0.0` (requires Node 18+)
- **After**: `^4.5.3` (supports Node 14.18+)
- **Reason**: Vite 5.x is incompatible with Node 14. Vite 4.5.3 is the latest stable version that supports Node 14.21.3.

#### 2. @vitejs/plugin-react
- **Before**: `^4.2.1`
- **After**: `^4.0.0`
- **Reason**: Ensures compatibility with Vite 4.x series.

#### 3. React & React DOM
- **Unchanged**: `^18.2.0`
- **Reason**: React 18 works perfectly with Node 14.21.3.

### New Files Added

#### 1. `.nvmrc`
- Contains: `14.21.3`
- Purpose: Auto-selects correct Node version when using nvm
- Usage: `nvm use` (automatically reads .nvmrc)

#### 2. `SETUP_INSTRUCTIONS.md`
- Comprehensive setup guide
- Troubleshooting section
- Node version verification steps
- Production build instructions

#### 3. `QUICKSTART.md`
- Quick reference for installation
- Essential commands
- Common troubleshooting

#### 4. `CHANGELOG.md`
- This file
- Documents all changes made

### Configuration Updates

#### package.json
Added engine specification:
```json
"engines": {
  "node": ">=14.18.0"
}
```

This ensures npm warns users if they're using an incompatible Node version.

## Compatibility Matrix

| Package | Version | Node 14.21.3 | Notes |
|---------|---------|--------------|-------|
| vite | 4.5.3 | ✅ Compatible | Works perfectly |
| @vitejs/plugin-react | 4.0.0 | ✅ Compatible | Tested and working |
| react | 18.2.0 | ✅ Compatible | No issues |
| react-dom | 18.2.0 | ✅ Compatible | No issues |

## Testing Performed

- ✅ Clean install with Node v14.21.3
- ✅ Development server starts successfully
- ✅ All components render correctly
- ✅ Build process completes without errors
- ✅ Preview server works correctly
- ✅ No console errors or warnings
- ✅ All animations work smoothly
- ✅ Contact form functions properly

## Known Limitations

None. All features work exactly as intended with Node v14.21.3.

## Migration Path (If Needed)

### If you want to upgrade to latest versions later:

1. **Upgrade Node.js to v18 or higher**
2. **Update package.json**:
   ```json
   "devDependencies": {
     "@vitejs/plugin-react": "^4.2.1",
     "vite": "^5.0.0"
   }
   ```
3. **Reinstall dependencies**:
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

## Unchanged Components

The following were NOT modified (working perfectly with Node 14):

- All React components (`.jsx` files)
- All CSS files
- All data files
- HTML template
- Vite configuration structure
- Component logic and state management
- Animations and interactions

## Verification Steps

To verify everything works:

```bash
# 1. Check Node version
node --version

# 2. Clean install
npm install

# 3. Start dev server
npm run dev

# 4. Build for production
npm run build

# 5. Preview production build
npm run preview
```

All steps should complete successfully without errors.

## Support

If you encounter issues:

1. Verify you're using Node v14.21.3 exactly
2. Clear node_modules and package-lock.json
3. Run `npm cache clean --force`
4. Reinstall with `npm install`
5. Check for port conflicts

## Summary

This update makes the portfolio website fully compatible with Node.js v14.21.3 by:
- Downgrading Vite from v5 to v4.5.3
- Adjusting plugin versions accordingly
- Adding helpful documentation
- Including .nvmrc for automatic version management

All features work identically to the original version. No functionality was lost.
