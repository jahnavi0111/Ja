import React, { useEffect, useState } from 'react';
import Navbar from './components/Navbar';
import Hero3D from './components/Hero3D';
import ParticlesBackground from './components/ParticlesBackground';
import About from './components/About';
import Skills3D from './components/Skills3D';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ScrollProgress from './components/ScrollProgress';

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (loading) {
    return (
      <div className="loader-container">
        <div className="loader">
          <div className="loader-ring"></div>
          <div className="loader-ring"></div>
          <div className="loader-ring"></div>
          <div className="loader-text">Loading Experience...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <ScrollProgress />
      <ParticlesBackground />
      <Navbar />
      <main>
        <Hero3D />
        <About />
        <Skills3D />
        <Projects />
        <Experience />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
