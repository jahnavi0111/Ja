import React from 'react';
import { motion } from 'framer-motion';
import '../styles/Experience.css';

const Experience = () => {
  const experiences = [
    {
      year: '2023 - Present',
      role: 'Senior Creative Developer',
      company: 'Digital Innovation Lab',
      description: 'Leading 3D web experiences and interactive installations using Three.js and WebGL',
      technologies: ['Three.js', 'React', 'WebGL', 'GSAP']
    },
    {
      year: '2021 - 2023',
      role: 'Frontend Developer',
      company: 'TechVision Studios',
      description: 'Built award-winning web applications with focus on performance and user experience',
      technologies: ['React', 'Next.js', 'TypeScript', 'Framer Motion']
    },
    {
      year: '2019 - 2021',
      role: 'Web Developer',
      company: 'Creative Agency Co.',
      description: 'Developed responsive websites and progressive web applications for various clients',
      technologies: ['HTML5', 'CSS3', 'JavaScript', 'Vue.js']
    }
  ];

  return (
    <section className="experience" id="experience">
      <div className="experience-container">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="section-header"
        >
          <h2 className="gradient-text">Experience</h2>
          <p>My professional journey</p>
        </motion.div>

        <div className="timeline">
          {experiences.map((exp, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
              className={`timeline-item ${index % 2 === 0 ? 'left' : 'right'}`}
            >
              <div className="timeline-content">
                <span className="timeline-year">{exp.year}</span>
                <h3>{exp.role}</h3>
                <h4>{exp.company}</h4>
                <p>{exp.description}</p>
                <div className="exp-tech">
                  {exp.technologies.map((tech, idx) => (
                    <span key={idx} className="tech-pill">{tech}</span>
                  ))}
                </div>
              </div>
              <div className="timeline-dot"></div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
