import React from 'react';
import { FiGithub, FiLinkedin, FiTwitter, FiMail, FiHeart } from 'react-icons/fi';
import '../styles/Footer.css';

const Footer = () => {
  const socialLinks = [
    { icon: <FiGithub />, url: 'https://github.com' },
    { icon: <FiLinkedin />, url: 'https://linkedin.com' },
    { icon: <FiTwitter />, url: 'https://twitter.com' },
    { icon: <FiMail />, url: 'mailto:your@email.com' }
  ];

  const quickLinks = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Projects', href: '#projects' },
    { name: 'Experience', href: '#experience' },
    { name: 'Contact', href: '#contact' }
  ];

  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3 className="gradient-text">Portfolio</h3>
          <p>
            Building amazing web experiences with modern technologies.
            Let's create something great together!
          </p>
          <div className="footer-social">
            {socialLinks.map((link, index) => (
              <a
                key={index}
                href={link.url}
                target="_blank"
                rel="noopener noreferrer"
                className="social-link"
              >
                {link.icon}
              </a>
            ))}
          </div>
        </div>

        <div className="footer-section">
          <h4>Quick Links</h4>
          <ul className="footer-links">
            {quickLinks.map((link, index) => (
              <li key={index}>
                <a href={link.href}>{link.name}</a>
              </li>
            ))}
          </ul>
        </div>

        <div className="footer-section">
          <h4>Get In Touch</h4>
          <ul className="footer-contact">
            <li>your@email.com</li>
            <li>+1 (555) 123-4567</li>
            <li>Your City, Country</li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom">
        <p>
          Made with <FiHeart className="heart" /> by Your Name © {new Date().getFullYear()}
        </p>
      </div>
    </footer>
  );
};

export default Footer;
