import React from 'react';
import { motion } from 'framer-motion';
import { FiCode, FiZap, FiHeart } from 'react-icons/fi';
import '../styles/About.css';

const About = () => {
  const stats = [
    { number: '50+', label: 'Projects Completed' },
    { number: '5+', label: 'Years Experience' },
    { number: '30+', label: 'Happy Clients' },
  ];

  const highlights = [
    {
      icon: <FiCode />,
      title: 'Clean Code',
      description: 'Writing maintainable, scalable code following best practices'
    },
    {
      icon: <FiZap />,
      title: 'Fast Performance',
      description: 'Optimized applications for lightning-fast user experiences'
    },
    {
      icon: <FiHeart />,
      title: 'User-Focused',
      description: 'Designing with empathy and accessibility in mind'
    }
  ];

  return (
    <section id="about" className="about">
      <div className="section-header">
        <h2>About Me</h2>
        <p>Get to know more about my skills and experience</p>
      </div>

      <div className="about-container">
        <motion.div 
          className="about-content"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h3>Hello! I'm a passionate developer</h3>
          <p>
            With over 5 years of experience in web development, I specialize in creating 
            modern, responsive, and user-friendly applications. My expertise spans across 
            the full stack, from crafting pixel-perfect frontends to building robust backend systems.
          </p>
          <p>
            I'm constantly learning and adapting to new technologies, ensuring that I deliver 
            cutting-edge solutions that meet the evolving needs of the digital landscape.
          </p>

          <div className="about-stats">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="stat-card"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5 }}
              >
                <h4 className="gradient-text">{stat.number}</h4>
                <p>{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        <motion.div 
          className="about-highlights"
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          {highlights.map((item, index) => (
            <motion.div
              key={index}
              className="highlight-card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="highlight-icon">{item.icon}</div>
              <h4>{item.title}</h4>
              <p>{item.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default About;
