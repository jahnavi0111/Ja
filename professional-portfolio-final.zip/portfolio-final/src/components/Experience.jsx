import React from 'react';
import { motion } from 'framer-motion';
import '../styles/Experience.css';

const Experience = () => {
  const experiences = [
    {
      year: '2023 - Present',
      title: 'Senior Full Stack Developer',
      company: 'Tech Company Inc.',
      description: 'Leading development of scalable web applications and mentoring junior developers.',
      highlights: [
        'Architected microservices infrastructure',
        'Reduced page load time by 60%',
        'Led team of 5 developers'
      ]
    },
    {
      year: '2021 - 2023',
      title: 'Full Stack Developer',
      company: 'Digital Agency Co.',
      description: 'Developed custom web solutions for diverse client base.',
      highlights: [
        'Built 20+ client websites',
        'Implemented CI/CD pipelines',
        'Improved code quality standards'
      ]
    },
    {
      year: '2019 - 2021',
      title: 'Frontend Developer',
      company: 'Startup Labs',
      description: 'Created responsive user interfaces and interactive web experiences.',
      highlights: [
        'Designed UI component library',
        'Collaborated with UX team',
        'Optimized mobile experience'
      ]
    }
  ];

  return (
    <section id="experience" className="experience">
      <div className="section-header">
        <h2>Work Experience</h2>
        <p>My professional journey and achievements</p>
      </div>

      <div className="timeline">
        {experiences.map((exp, index) => (
          <motion.div
            key={index}
            className="timeline-item"
            initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: index * 0.2 }}
          >
            <div className="timeline-dot"></div>
            <div className="timeline-content">
              <span className="timeline-year">{exp.year}</span>
              <h3>{exp.title}</h3>
              <h4>{exp.company}</h4>
              <p>{exp.description}</p>
              <ul>
                {exp.highlights.map((highlight, i) => (
                  <li key={i}>{highlight}</li>
                ))}
              </ul>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Experience;
