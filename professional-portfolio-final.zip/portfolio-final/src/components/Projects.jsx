import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FiGithub, FiExternalLink } from 'react-icons/fi';
import '../styles/Projects.css';

const Projects = () => {
  const [filter, setFilter] = useState('all');

  const projects = [
    {
      title: 'E-Commerce Platform',
      category: 'web',
      description: 'Full-stack e-commerce solution with payment integration and admin dashboard',
      tech: ['React', 'Node.js', 'MongoDB', 'Stripe'],
      image: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      github: '#',
      live: '#'
    },
    {
      title: 'Task Management App',
      category: 'web',
      description: 'Collaborative task manager with real-time updates and team features',
      tech: ['React', 'Firebase', 'Material-UI'],
      image: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)',
      github: '#',
      live: '#'
    },
    {
      title: 'Portfolio CMS',
      category: 'web',
      description: 'Custom CMS for portfolio websites with drag-and-drop builder',
      tech: ['Next.js', 'PostgreSQL', 'Tailwind'],
      image: 'linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)',
      github: '#',
      live: '#'
    },
    {
      title: 'Weather Dashboard',
      category: 'app',
      description: 'Beautiful weather app with forecasts and location-based alerts',
      tech: ['React Native', 'OpenWeather API'],
      image: 'linear-gradient(135deg, #fa709a 0%, #fee140 100%)',
      github: '#',
      live: '#'
    },
    {
      title: 'Social Media Dashboard',
      category: 'web',
      description: 'Analytics dashboard for managing multiple social media accounts',
      tech: ['Vue.js', 'Express', 'Chart.js'],
      image: 'linear-gradient(135deg, #30cfd0 0%, #330867 100%)',
      github: '#',
      live: '#'
    },
    {
      title: 'Fitness Tracker',
      category: 'app',
      description: 'Mobile app for tracking workouts and nutrition with AI insights',
      tech: ['Flutter', 'Firebase', 'TensorFlow'],
      image: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
      github: '#',
      live: '#'
    }
  ];

  const filteredProjects = filter === 'all' 
    ? projects 
    : projects.filter(p => p.category === filter);

  return (
    <section id="projects" className="projects">
      <div className="section-header">
        <h2>Featured Projects</h2>
        <p>Some of my recent work and side projects</p>
      </div>

      <div className="filter-buttons">
        {['all', 'web', 'app'].map((cat) => (
          <button
            key={cat}
            className={`filter-btn ${filter === cat ? 'active' : ''}`}
            onClick={() => setFilter(cat)}
          >
            {cat.charAt(0).toUpperCase() + cat.slice(1)}
          </button>
        ))}
      </div>

      <div className="projects-grid">
        {filteredProjects.map((project, index) => (
          <motion.div
            key={index}
            className="project-card"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
            layout
          >
            <div className="project-image" style={{ background: project.image }}>
              <div className="project-overlay">
                <a href={project.github} className="project-link">
                  <FiGithub />
                </a>
                <a href={project.live} className="project-link">
                  <FiExternalLink />
                </a>
              </div>
            </div>
            <div className="project-content">
              <h3>{project.title}</h3>
              <p>{project.description}</p>
              <div className="project-tech">
                {project.tech.map((tech, i) => (
                  <span key={i} className="tech-tag">{tech}</span>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Projects;
