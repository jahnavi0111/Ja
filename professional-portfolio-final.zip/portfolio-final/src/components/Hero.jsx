import React from 'react';
import { motion } from 'framer-motion';
import { FiArrowDown, FiGithub, FiLinkedin, FiMail } from 'react-icons/fi';
import '../styles/Hero.css';

const Hero = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' }
    }
  };

  return (
    <section id="home" className="hero">
      {/* Animated Background Graphics */}
      <div className="hero-bg">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
        <div className="floating-shape shape-4"></div>
      </div>

      <motion.div 
        className="hero-content"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        <motion.div className="hero-tag" variants={itemVariants}>
          👋 Welcome to my portfolio
        </motion.div>

        <motion.h1 className="hero-title" variants={itemVariants}>
          Hi, I'm <span className="gradient-text">Your Name</span>
        </motion.h1>

        <motion.h2 className="hero-subtitle" variants={itemVariants}>
          Full Stack Developer & UI/UX Designer
        </motion.h2>

        <motion.p className="hero-description" variants={itemVariants}>
          I craft beautiful, performant web experiences that users love.
          Specialized in React, Node.js, and modern web technologies.
        </motion.p>

        <motion.div className="hero-buttons" variants={itemVariants}>
          <a href="#projects" className="btn btn-primary">
            View My Work
          </a>
          <a href="#contact" className="btn btn-secondary">
            Get In Touch
          </a>
        </motion.div>

        <motion.div className="hero-social" variants={itemVariants}>
          <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="social-icon">
            <FiGithub />
          </a>
          <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="social-icon">
            <FiLinkedin />
          </a>
          <a href="mailto:your@email.com" className="social-icon">
            <FiMail />
          </a>
        </motion.div>
      </motion.div>

      <motion.div 
        className="scroll-indicator"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
      >
        <FiArrowDown />
      </motion.div>
    </section>
  );
};

export default Hero;
