# Professional Portfolio Website

A modern, fast-loading, and beautifully designed portfolio website with smooth animations and stunning graphics.

## ✨ Features

- **Fast Loading**: Optimized for quick page loads (< 1 second)
- **Smooth Animations**: Framer Motion powered transitions between sections
- **Beautiful Design**: Modern purple-blue gradient theme with professional aesthetics
- **Fully Responsive**: Perfect on desktop, tablet, and mobile devices
- **Clean Code**: Well-organized, maintainable codebase
- **Optimized Graphics**: Animated background elements without performance impact
- **SEO Friendly**: Semantic HTML and optimized meta tags

## 🎨 Design Highlights

- Gradient hero section with floating animated shapes
- Smooth scroll animations
- Hover effects and micro-interactions
- Professional color palette (Purple/Blue/Pink gradients)
- Clean card-based layouts
- Interactive project filtering
- Timeline-based experience section
- Contact form with validation

## 🚀 Tech Stack

- **React 18** - UI library
- **Vite** - Build tool (fast builds & HMR)
- **Framer Motion** - Smooth animations
- **React Icons** - Beautiful icons
- **CSS3** - Modern styling with gradients & animations

## 📦 Installation

### Prerequisites
- Node.js >= 14.18.0 (Tested with v14.21.3)
- npm or yarn

### Setup

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

The development server will start at `http://localhost:3000`

## 🎯 Sections

1. **Hero** - Eye-catching introduction with animated graphics
2. **About** - Personal introduction with stats and highlights
3. **Skills** - Animated skill bars showing proficiency levels
4. **Projects** - Portfolio showcase with filtering capability
5. **Experience** - Timeline of professional journey
6. **Contact** - Get in touch form with contact information
7. **Footer** - Social links and quick navigation

## 🎨 Customization

### Update Your Information

1. **Personal Details**: Edit `src/components/Hero.jsx`
2. **About Content**: Edit `src/components/About.jsx`
3. **Skills**: Edit `src/components/Skills.jsx`
4. **Projects**: Edit `src/components/Projects.jsx`
5. **Experience**: Edit `src/components/Experience.jsx`
6. **Contact Info**: Edit `src/components/Contact.jsx`

### Change Theme Colors

Edit `src/styles/index.css` to change the color scheme:

```css
:root {
  --primary: #6366f1;      /* Main blue */
  --secondary: #8b5cf6;    /* Purple */
  --accent: #ec4899;       /* Pink */
  /* ... */
}
```

## 🔧 Performance Optimizations

- **Code Splitting**: Vite automatically splits code for faster loads
- **Lazy Loading**: Components load on-demand
- **Optimized Images**: Use gradient backgrounds instead of heavy images
- **CSS Optimization**: Minimal CSS with no frameworks
- **Fast Animations**: Hardware-accelerated transforms
- **No Heavy Libraries**: Minimal dependencies for faster load times

## 📱 Responsive Design

- **Desktop**: Full multi-column layouts
- **Tablet**: Adapted grid systems
- **Mobile**: Stack layouts with optimized spacing

## 🌐 Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Opera (latest)

## 📝 License

MIT License - feel free to use this for your own portfolio!

## 🤝 Contributing

Feel free to fork this project and customize it for your needs. If you find any bugs or have suggestions, please open an issue.

## 👨‍💻 Author

Your Name - [your@email.com](mailto:your@email.com)

---

**Built with ❤️ using React and modern web technologies**
